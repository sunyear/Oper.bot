
describe('md-_name_', function() {

  beforeEach(module('ngAria'));
  beforeEach(module('material.components._name_'));

  it('should ', function() {

  });

});
