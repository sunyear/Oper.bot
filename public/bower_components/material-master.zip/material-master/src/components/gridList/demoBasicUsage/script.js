
angular.module('gridListDemo1', ['ngMaterial'])
.controller('AppCtrl', function($scope) {});
