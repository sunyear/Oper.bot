require('./dest/angular-material-sidemenu.js');

module.exports = 'ngMaterialSidemenu';
