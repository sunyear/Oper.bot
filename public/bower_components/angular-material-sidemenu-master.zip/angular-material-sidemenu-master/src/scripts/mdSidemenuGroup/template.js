export default function() {

  return '<div class="md-sidemenu-group" flex layout="column" layout-align="start start" ng-transclude></div>';

}
